//! Adapt evdev events to the recognizer, then compose the virtual touchpad stream.
//!
//! Routing decides which contacts survive. Composition rebuilds pointer-emulation
//! state from those contacts; copying the physical device's global state would
//! let an edge-owned finger affect the pointer. Both stages run in raw replay.

use std::collections::BTreeSet;
use std::time::Duration;

use crate::core::{
    AxisRange, Capabilities, Engine, Event, Gesture, ResyncContact, SliderStep, SlotError,
};

pub const EV_SYN: u16 = 0x00;
pub const EV_KEY: u16 = 0x01;
pub const EV_ABS: u16 = 0x03;
pub const EV_MSC: u16 = 0x04;

pub const SYN_REPORT: u16 = 0x00;
pub const SYN_DROPPED: u16 = 0x03;
pub const MSC_TIMESTAMP: u16 = 0x05;

pub const BTN_LEFT: u16 = 0x110;
pub const BTN_RIGHT: u16 = 0x111;
pub const BTN_MIDDLE: u16 = 0x112;
pub const BTN_SIDE: u16 = 0x113;
pub const BTN_EXTRA: u16 = 0x114;
pub const BTN_FORWARD: u16 = 0x115;
pub const BTN_BACK: u16 = 0x116;
pub const BTN_TASK: u16 = 0x117;
pub const BTN_TOOL_FINGER: u16 = 0x145;
pub const BTN_TOOL_QUINTTAP: u16 = 0x148;
pub const BTN_TOUCH: u16 = 0x14a;
pub const BTN_TOOL_DOUBLETAP: u16 = 0x14d;
pub const BTN_TOOL_TRIPLETAP: u16 = 0x14e;
pub const BTN_TOOL_QUADTAP: u16 = 0x14f;

pub const ABS_X: u16 = 0x00;
pub const ABS_Y: u16 = 0x01;
pub const ABS_MT_SLOT: u16 = 0x2f;
pub const ABS_MT_TOUCH_MAJOR: u16 = 0x30;
pub const ABS_MT_TOUCH_MINOR: u16 = 0x31;
pub const ABS_MT_WIDTH_MAJOR: u16 = 0x32;
pub const ABS_MT_WIDTH_MINOR: u16 = 0x33;
pub const ABS_MT_ORIENTATION: u16 = 0x34;
pub const ABS_MT_POSITION_X: u16 = 0x35;
pub const ABS_MT_POSITION_Y: u16 = 0x36;
pub const ABS_MT_TOOL_TYPE: u16 = 0x37;
pub const ABS_MT_BLOB_ID: u16 = 0x38;
pub const ABS_MT_TRACKING_ID: u16 = 0x39;
pub const ABS_MT_PRESSURE: u16 = 0x3a;
pub const ABS_MT_DISTANCE: u16 = 0x3b;
pub const ABS_MT_TOOL_X: u16 = 0x3c;
pub const ABS_MT_TOOL_Y: u16 = 0x3d;

pub const fn is_pointer_button_code(code: u16) -> bool {
    matches!(code, BTN_LEFT..=BTN_TASK)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RawEvent {
    pub kind: u16,
    pub code: u16,
    pub value: i32,
}

impl RawEvent {
    pub const fn new(kind: u16, code: u16, value: i32) -> Self {
        Self { kind, code, value }
    }

    pub const fn syn_report() -> Self {
        Self::new(EV_SYN, SYN_REPORT, 0)
    }

    pub const fn syn_dropped() -> Self {
        Self::new(EV_SYN, SYN_DROPPED, 0)
    }

    pub const fn btn_touch(pressed: bool) -> Self {
        Self::new(EV_KEY, BTN_TOUCH, pressed as i32)
    }

    pub const fn btn_tool_finger(pressed: bool) -> Self {
        Self::new(EV_KEY, BTN_TOOL_FINGER, pressed as i32)
    }

    pub const fn btn_tool_doubletap(pressed: bool) -> Self {
        Self::new(EV_KEY, BTN_TOOL_DOUBLETAP, pressed as i32)
    }

    pub const fn btn_tool_tripletap(pressed: bool) -> Self {
        Self::new(EV_KEY, BTN_TOOL_TRIPLETAP, pressed as i32)
    }

    pub const fn btn_tool_quadtap(pressed: bool) -> Self {
        Self::new(EV_KEY, BTN_TOOL_QUADTAP, pressed as i32)
    }

    pub const fn btn_tool_quinttap(pressed: bool) -> Self {
        Self::new(EV_KEY, BTN_TOOL_QUINTTAP, pressed as i32)
    }

    pub const fn abs_x(value: i32) -> Self {
        Self::new(EV_ABS, ABS_X, value)
    }

    pub const fn abs_y(value: i32) -> Self {
        Self::new(EV_ABS, ABS_Y, value)
    }

    pub const fn msc_timestamp(value: i32) -> Self {
        Self::new(EV_MSC, MSC_TIMESTAMP, value)
    }

    pub const fn abs_mt_slot(slot: i32) -> Self {
        Self::new(EV_ABS, ABS_MT_SLOT, slot)
    }

    pub const fn abs_mt_tracking_id(tracking_id: i32) -> Self {
        Self::new(EV_ABS, ABS_MT_TRACKING_ID, tracking_id)
    }

    pub const fn abs_mt_position_x(x: i32) -> Self {
        Self::new(EV_ABS, ABS_MT_POSITION_X, x)
    }

    pub const fn abs_mt_position_y(y: i32) -> Self {
        Self::new(EV_ABS, ABS_MT_POSITION_Y, y)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RawParseError {
    MissingField {
        line: usize,
        field: &'static str,
    },
    ExtraField {
        line: usize,
    },
    InvalidInteger {
        line: usize,
        field: &'static str,
        value: String,
    },
    UnknownEventType {
        line: usize,
        name: String,
    },
    UnknownCode {
        line: usize,
        event_type: String,
        code: String,
    },
    InvalidMetadataRange {
        line: usize,
        field: &'static str,
        value: String,
    },
    MissingMetadataField {
        field: &'static str,
    },
    InvalidTimestamp {
        line: usize,
        value: String,
    },
    NonMonotonicTimestamp {
        line: usize,
        previous_us: u64,
        current_us: u64,
    },
    UnterminatedFrame {
        line: usize,
    },
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RawFrame {
    pub events: Vec<RawEvent>,
    pub timestamp: Option<Duration>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RawDumpFile {
    pub capabilities: Option<Capabilities>,
    pub frames: Vec<RawFrame>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RoutedRawFrame {
    pub passthrough: Vec<RawEvent>,
    pub physical_buttons: Vec<RawEvent>,
    pub gestures: Vec<Gesture>,
    pub slider_steps: Vec<SliderStep>,
    pub resync_required: bool,
}

/// Tracks the contacts and buttons visible to the virtual device, independently
/// of physical state. `finish` releases that output state before shutdown.
#[derive(Debug, Clone)]
pub struct RawOutputComposer {
    caps: Capabilities,
    current_slot: i32,
    slots: Vec<RawOutputSlotState>,
    last_touch_down: bool,
    last_tool_count: usize,
    last_abs_x: Option<i32>,
    last_abs_y: Option<i32>,
    pressed_physical_buttons: BTreeSet<u16>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
struct RawOutputSlotState {
    active: bool,
    x: Option<i32>,
    y: Option<i32>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RawOutputError<E> {
    Compose(SlotError),
    Sink(E),
}

/// Frame output boundary shared by the recording sink and uinput.
/// `emit` receives frame contents; `sync` commits the frame. Callers do not emit
/// `SYN_REPORT` themselves, since the live writer supplies it.
pub trait RawOutputSink {
    type Error;

    fn emit(&mut self, event: RawEvent) -> Result<(), Self::Error>;
    fn sync(&mut self) -> Result<(), Self::Error>;
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RecordingRawOutputSink {
    frames: Vec<RawFrame>,
    current: Vec<RawEvent>,
}

impl RecordingRawOutputSink {
    pub fn frames(&self) -> &[RawFrame] {
        &self.frames
    }

    pub fn into_frames(self) -> Vec<RawFrame> {
        self.frames
    }
}

impl RawOutputSink for RecordingRawOutputSink {
    type Error = std::convert::Infallible;

    fn emit(&mut self, event: RawEvent) -> Result<(), Self::Error> {
        self.current.push(event);
        Ok(())
    }

    fn sync(&mut self) -> Result<(), Self::Error> {
        if !self.current.is_empty() {
            self.frames
                .push(RawFrame::new(std::mem::take(&mut self.current)));
        }
        Ok(())
    }
}

impl RawFrame {
    pub fn new(events: Vec<RawEvent>) -> Self {
        Self {
            events,
            timestamp: None,
        }
    }

    pub fn new_at(events: Vec<RawEvent>, timestamp: Duration) -> Self {
        Self {
            events,
            timestamp: Some(timestamp),
        }
    }
}

impl RawOutputComposer {
    pub fn new(caps: Capabilities) -> Self {
        assert!(
            caps.slot_min <= caps.slot_max,
            "invalid slot range: {}..={} ",
            caps.slot_min,
            caps.slot_max
        );
        let slot_count = (caps.slot_max - caps.slot_min + 1) as usize;
        Self {
            current_slot: caps.slot_min,
            caps,
            slots: vec![RawOutputSlotState::default(); slot_count],
            last_touch_down: false,
            last_tool_count: 0,
            last_abs_x: None,
            last_abs_y: None,
            pressed_physical_buttons: BTreeSet::new(),
        }
    }

    pub fn compose_frame(&mut self, routed: &RoutedRawFrame) -> Result<RawFrame, SlotError> {
        if routed.resync_required {
            let events = self.release_all_tracked_contacts()?;
            self.reset();
            return Ok(RawFrame::new(events));
        }

        let mut events = Vec::new();
        for event in routed.passthrough.iter().copied() {
            self.apply_passthrough_event(event)?;
            events.push(event);
        }
        self.append_legacy_state_events(&mut events);
        // libinput needs the promoted contact's position before the click event
        // to recognize a click-drag that started inside an edge zone.
        for event in routed.physical_buttons.iter().copied() {
            self.apply_physical_button_event(event);
            events.push(event);
        }

        Ok(RawFrame::new(events))
    }

    pub fn finish(&mut self) -> Result<RawFrame, SlotError> {
        let events = self.release_all_tracked_contacts()?;
        self.reset();
        Ok(RawFrame::new(events))
    }

    fn apply_passthrough_event(&mut self, event: RawEvent) -> Result<(), SlotError> {
        match (event.kind, event.code) {
            (EV_ABS, ABS_MT_SLOT) => {
                self.ensure_slot(event.value)?;
                self.current_slot = event.value;
            }
            (EV_ABS, ABS_MT_TRACKING_ID) if event.value >= 0 => {
                let slot = self.slot_mut(self.current_slot)?;
                slot.active = true;
                slot.x = None;
                slot.y = None;
            }
            (EV_ABS, ABS_MT_TRACKING_ID) => {
                let slot = self.slot_mut(self.current_slot)?;
                slot.active = false;
                slot.x = None;
                slot.y = None;
            }
            (EV_ABS, ABS_MT_POSITION_X) => {
                self.slot_mut(self.current_slot)?.x = Some(event.value);
            }
            (EV_ABS, ABS_MT_POSITION_Y) => {
                self.slot_mut(self.current_slot)?.y = Some(event.value);
            }
            _ => {}
        }
        Ok(())
    }

    fn apply_physical_button_event(&mut self, event: RawEvent) {
        if event.kind != EV_KEY || !is_pointer_button_code(event.code) {
            return;
        }
        if event.value == 0 {
            self.pressed_physical_buttons.remove(&event.code);
        } else {
            self.pressed_physical_buttons.insert(event.code);
        }
    }

    fn append_legacy_state_events(&mut self, events: &mut Vec<RawEvent>) {
        let active_count = self.active_slot_count();
        let touch_down = active_count > 0;

        if self.last_touch_down != touch_down {
            events.push(RawEvent::btn_touch(touch_down));
            self.last_touch_down = touch_down;
        }

        if self.last_tool_count != active_count {
            if let Some(previous_tool) = tool_event_for_contact_count(self.last_tool_count, false) {
                events.push(previous_tool);
            }
            if let Some(next_tool) = tool_event_for_contact_count(active_count, true) {
                events.push(next_tool);
            }
            self.last_tool_count = active_count;
        }

        if let Some((x, y)) = self.representative_position() {
            if self.last_abs_x != Some(x) {
                events.push(RawEvent::abs_x(x));
                self.last_abs_x = Some(x);
            }
            if self.last_abs_y != Some(y) {
                events.push(RawEvent::abs_y(y));
                self.last_abs_y = Some(y);
            }
        } else {
            self.last_abs_x = None;
            self.last_abs_y = None;
        }
    }

    fn active_slot_count(&self) -> usize {
        self.slots.iter().filter(|slot| slot.active).count()
    }

    fn representative_position(&self) -> Option<(i32, i32)> {
        self.slots
            .iter()
            .find(|slot| slot.active && slot.x.is_some() && slot.y.is_some())
            .and_then(|slot| Some((slot.x?, slot.y?)))
    }

    fn release_all_tracked_contacts(&mut self) -> Result<Vec<RawEvent>, SlotError> {
        let mut events = Vec::new();
        let mut emitted_current_slot = self.current_slot;
        for index in 0..self.slots.len() {
            if !self.slots[index].active {
                continue;
            }
            let slot = self.caps.slot_min + index as i32;
            if slot != emitted_current_slot {
                events.push(RawEvent::abs_mt_slot(slot));
                emitted_current_slot = slot;
            }
            events.push(RawEvent::abs_mt_tracking_id(-1));
        }
        self.clear_slot_state();
        self.append_legacy_state_events(&mut events);
        for code in std::mem::take(&mut self.pressed_physical_buttons) {
            events.push(RawEvent::new(EV_KEY, code, 0));
        }
        Ok(events)
    }

    fn reset(&mut self) {
        self.clear_slot_state();
        self.current_slot = self.caps.slot_min;
        self.last_touch_down = false;
        self.last_tool_count = 0;
        self.last_abs_x = None;
        self.last_abs_y = None;
        self.pressed_physical_buttons.clear();
    }

    fn clear_slot_state(&mut self) {
        for slot in &mut self.slots {
            *slot = RawOutputSlotState::default();
        }
    }

    fn ensure_slot(&self, slot: i32) -> Result<(), SlotError> {
        if slot < self.caps.slot_min || slot > self.caps.slot_max {
            return Err(SlotError::SlotOutOfRange {
                slot,
                min: self.caps.slot_min,
                max: self.caps.slot_max,
            });
        }
        Ok(())
    }

    fn slot_index(&self, slot: i32) -> Result<usize, SlotError> {
        self.ensure_slot(slot)?;
        Ok((slot - self.caps.slot_min) as usize)
    }

    fn slot_mut(&mut self, slot: i32) -> Result<&mut RawOutputSlotState, SlotError> {
        let index = self.slot_index(slot)?;
        Ok(&mut self.slots[index])
    }
}

pub fn write_raw_output_frame<S>(
    composer: &mut RawOutputComposer,
    routed: &RoutedRawFrame,
    sink: &mut S,
) -> Result<(), RawOutputError<S::Error>>
where
    S: RawOutputSink,
{
    let frame = composer
        .compose_frame(routed)
        .map_err(RawOutputError::Compose)?;
    if frame.events.is_empty() {
        return Ok(());
    }

    for event in frame.events {
        sink.emit(event).map_err(RawOutputError::Sink)?;
    }
    sink.sync().map_err(RawOutputError::Sink)
}

fn tool_event_for_contact_count(count: usize, pressed: bool) -> Option<RawEvent> {
    match count {
        0 => None,
        1 => Some(RawEvent::btn_tool_finger(pressed)),
        2 => Some(RawEvent::btn_tool_doubletap(pressed)),
        3 => Some(RawEvent::btn_tool_tripletap(pressed)),
        4 => Some(RawEvent::btn_tool_quadtap(pressed)),
        _ => Some(RawEvent::btn_tool_quinttap(pressed)),
    }
}

pub fn parse_raw_dump_file(input: &str) -> Result<RawDumpFile, RawParseError> {
    Ok(RawDumpFile {
        capabilities: parse_capabilities_metadata(input)?,
        frames: parse_raw_frames(input)?,
    })
}

#[derive(Default)]
struct CapabilityMetadata {
    slots: Option<AxisRange>,
    x: Option<AxisRange>,
    y: Option<AxisRange>,
    saw_any: bool,
}

fn parse_capabilities_metadata(input: &str) -> Result<Option<Capabilities>, RawParseError> {
    let mut metadata = CapabilityMetadata::default();

    for (index, raw_line) in input.lines().enumerate() {
        let line_number = index + 1;
        let Some(comment) = raw_line.trim_start().strip_prefix('#') else {
            continue;
        };
        let Some((name, value)) = comment.trim().split_once(':') else {
            continue;
        };
        let name = name.trim();
        let value = value.trim();

        match name {
            "slots" => {
                metadata.saw_any = true;
                metadata.slots = Some(parse_metadata_range(line_number, "slots", value)?);
            }
            "x" => {
                metadata.saw_any = true;
                metadata.x = Some(parse_metadata_range(line_number, "x", value)?);
            }
            "y" => {
                metadata.saw_any = true;
                metadata.y = Some(parse_metadata_range(line_number, "y", value)?);
            }
            _ => {}
        }
    }

    if !metadata.saw_any {
        return Ok(None);
    }

    let slots = metadata
        .slots
        .ok_or(RawParseError::MissingMetadataField { field: "slots" })?;
    let x = metadata
        .x
        .ok_or(RawParseError::MissingMetadataField { field: "x" })?;
    let y = metadata
        .y
        .ok_or(RawParseError::MissingMetadataField { field: "y" })?;

    Ok(Some(Capabilities {
        slot_min: slots.min,
        slot_max: slots.max,
        x,
        y,
    }))
}

fn parse_metadata_range(
    line: usize,
    field: &'static str,
    value: &str,
) -> Result<AxisRange, RawParseError> {
    let Some((min, max)) = value.split_once("..=") else {
        return Err(RawParseError::InvalidMetadataRange {
            line,
            field,
            value: value.to_string(),
        });
    };
    let min = min
        .trim()
        .parse::<i32>()
        .map_err(|_| RawParseError::InvalidMetadataRange {
            line,
            field,
            value: value.to_string(),
        })?;
    let max = max
        .trim()
        .parse::<i32>()
        .map_err(|_| RawParseError::InvalidMetadataRange {
            line,
            field,
            value: value.to_string(),
        })?;

    Ok(AxisRange { min, max })
}

pub fn parse_raw_frames(input: &str) -> Result<Vec<RawFrame>, RawParseError> {
    let mut frames = Vec::new();
    let mut current = Vec::new();
    let mut last_timestamp = None;

    for (index, raw_line) in input.lines().enumerate() {
        let line_number = index + 1;
        let line = raw_line
            .split_once('#')
            .map_or(raw_line, |(before_comment, _)| before_comment)
            .trim();

        if line.is_empty() {
            continue;
        }

        let (event, timestamp) = parse_raw_event_line(line_number, line)?;
        match (event.kind, event.code) {
            (EV_SYN, SYN_REPORT) => {
                let timestamp = parse_frame_timestamp(line_number, timestamp.as_deref())?;
                validate_frame_timestamp(line_number, timestamp, &mut last_timestamp)?;
                if !current.is_empty() {
                    frames.push(RawFrame::new_at(std::mem::take(&mut current), timestamp));
                }
            }
            (EV_SYN, SYN_DROPPED) => {
                let timestamp = parse_frame_timestamp(line_number, timestamp.as_deref())?;
                validate_frame_timestamp(line_number, timestamp, &mut last_timestamp)?;
                current.clear();
                frames.push(RawFrame::new_at(vec![event], timestamp));
            }
            _ => {
                if timestamp.is_some() {
                    return Err(RawParseError::ExtraField { line: line_number });
                }
                current.push(event);
            }
        }
    }

    if !current.is_empty() {
        return Err(RawParseError::UnterminatedFrame {
            line: input.lines().count().max(1),
        });
    }

    Ok(frames)
}

fn parse_raw_event_line(
    line: usize,
    raw_line: &str,
) -> Result<(RawEvent, Option<String>), RawParseError> {
    let mut parts = raw_line.split_whitespace();
    let event_type = parts.next().ok_or(RawParseError::MissingField {
        line,
        field: "event_type",
    })?;
    let code = parts.next().ok_or(RawParseError::MissingField {
        line,
        field: "code",
    })?;
    let value = parts.next().ok_or(RawParseError::MissingField {
        line,
        field: "value",
    })?;

    let timestamp = parts.next().map(str::to_string);
    if parts.next().is_some() {
        return Err(RawParseError::ExtraField { line });
    }

    let kind = parse_event_type(line, event_type)?;
    let code = parse_event_code(line, event_type, kind, code)?;
    let value = parse_i32_field(line, "value", value)?;

    Ok((RawEvent::new(kind, code, value), timestamp))
}

fn parse_frame_timestamp(line: usize, value: Option<&str>) -> Result<Duration, RawParseError> {
    let value = value.ok_or(RawParseError::MissingField {
        line,
        field: "timestamp_us",
    })?;
    let micros = value
        .parse::<u64>()
        .map_err(|_| RawParseError::InvalidTimestamp {
            line,
            value: value.to_string(),
        })?;
    Ok(Duration::from_micros(micros))
}

fn validate_frame_timestamp(
    line: usize,
    timestamp: Duration,
    last_timestamp: &mut Option<Duration>,
) -> Result<(), RawParseError> {
    if let Some(previous) = *last_timestamp {
        if timestamp < previous {
            return Err(RawParseError::NonMonotonicTimestamp {
                line,
                previous_us: previous.as_micros() as u64,
                current_us: timestamp.as_micros() as u64,
            });
        }
    }
    *last_timestamp = Some(timestamp);
    Ok(())
}

fn parse_event_type(line: usize, name: &str) -> Result<u16, RawParseError> {
    match name {
        "EV_SYN" => Ok(EV_SYN),
        "EV_KEY" => Ok(EV_KEY),
        "EV_ABS" => Ok(EV_ABS),
        "EV_MSC" => Ok(EV_MSC),
        _ => {
            let Some(raw) = name.strip_prefix("EV_") else {
                return Err(RawParseError::UnknownEventType {
                    line,
                    name: name.to_string(),
                });
            };
            parse_u16_field(line, "event_type", raw).map_err(|_| RawParseError::UnknownEventType {
                line,
                name: name.to_string(),
            })
        }
    }
}

fn parse_event_code(
    line: usize,
    event_type_name: &str,
    event_type: u16,
    code: &str,
) -> Result<u16, RawParseError> {
    if let Ok(value) = parse_u16_field(line, "code", code) {
        return Ok(value);
    }

    let value = match event_type {
        EV_SYN => synchronization_code_for_name(code),
        EV_KEY => key_code_for_name(code),
        EV_ABS => absolute_axis_code_for_name(code),
        EV_MSC => misc_code_for_name(code),
        _ => None,
    };

    value.ok_or_else(|| RawParseError::UnknownCode {
        line,
        event_type: event_type_name.to_string(),
        code: code.to_string(),
    })
}

fn parse_u16_field(line: usize, field: &'static str, value: &str) -> Result<u16, RawParseError> {
    value
        .parse::<u16>()
        .map_err(|_| RawParseError::InvalidInteger {
            line,
            field,
            value: value.to_string(),
        })
}

fn parse_i32_field(line: usize, field: &'static str, value: &str) -> Result<i32, RawParseError> {
    value
        .parse::<i32>()
        .map_err(|_| RawParseError::InvalidInteger {
            line,
            field,
            value: value.to_string(),
        })
}

fn synchronization_code_for_name(name: &str) -> Option<u16> {
    match name {
        "SYN_REPORT" => Some(SYN_REPORT),
        "SYN_DROPPED" => Some(SYN_DROPPED),
        _ => None,
    }
}

fn misc_code_for_name(name: &str) -> Option<u16> {
    match name {
        "MSC_TIMESTAMP" => Some(MSC_TIMESTAMP),
        _ => None,
    }
}

fn key_code_for_name(name: &str) -> Option<u16> {
    match name {
        "BTN_LEFT" => Some(BTN_LEFT),
        "BTN_RIGHT" => Some(BTN_RIGHT),
        "BTN_MIDDLE" => Some(BTN_MIDDLE),
        "BTN_SIDE" => Some(BTN_SIDE),
        "BTN_EXTRA" => Some(BTN_EXTRA),
        "BTN_TOOL_FINGER" => Some(BTN_TOOL_FINGER),
        "BTN_TOOL_QUINTTAP" => Some(BTN_TOOL_QUINTTAP),
        "BTN_TOUCH" => Some(BTN_TOUCH),
        "BTN_TOOL_DOUBLETAP" => Some(BTN_TOOL_DOUBLETAP),
        "BTN_TOOL_TRIPLETAP" => Some(BTN_TOOL_TRIPLETAP),
        "BTN_TOOL_QUADTAP" => Some(BTN_TOOL_QUADTAP),
        _ => None,
    }
}

fn absolute_axis_code_for_name(name: &str) -> Option<u16> {
    match name {
        "ABS_X" => Some(ABS_X),
        "ABS_Y" => Some(ABS_Y),
        "ABS_MT_SLOT" => Some(ABS_MT_SLOT),
        "ABS_MT_TOUCH_MAJOR" => Some(ABS_MT_TOUCH_MAJOR),
        "ABS_MT_TOUCH_MINOR" => Some(ABS_MT_TOUCH_MINOR),
        "ABS_MT_WIDTH_MAJOR" => Some(ABS_MT_WIDTH_MAJOR),
        "ABS_MT_WIDTH_MINOR" => Some(ABS_MT_WIDTH_MINOR),
        "ABS_MT_ORIENTATION" => Some(ABS_MT_ORIENTATION),
        "ABS_MT_POSITION_X" => Some(ABS_MT_POSITION_X),
        "ABS_MT_POSITION_Y" => Some(ABS_MT_POSITION_Y),
        "ABS_MT_TOOL_TYPE" => Some(ABS_MT_TOOL_TYPE),
        "ABS_MT_BLOB_ID" => Some(ABS_MT_BLOB_ID),
        "ABS_MT_TRACKING_ID" => Some(ABS_MT_TRACKING_ID),
        "ABS_MT_PRESSURE" => Some(ABS_MT_PRESSURE),
        "ABS_MT_DISTANCE" => Some(ABS_MT_DISTANCE),
        "ABS_MT_TOOL_X" => Some(ABS_MT_TOOL_X),
        "ABS_MT_TOOL_Y" => Some(ABS_MT_TOOL_Y),
        _ => None,
    }
}

pub fn extract_core_events(frame: &RawFrame) -> Vec<Event> {
    frame
        .events
        .iter()
        .filter_map(|event| core_event_for_raw_event(*event))
        .collect()
}

pub fn route_raw_frame(engine: &mut Engine, frame: &RawFrame) -> Result<RoutedRawFrame, SlotError> {
    let physical_buttons = frame
        .events
        .iter()
        .copied()
        .filter(|event| event.kind == EV_KEY && is_pointer_button_code(event.code))
        .collect::<Vec<_>>();
    let mut promoted_contacts = Vec::new();
    let mut canceled_tap_gestures = Vec::new();
    if physical_buttons.iter().any(|event| event.value != 0) {
        canceled_tap_gestures = engine.interrupt_tap_sequence();
    }
    // Treat a press as held for this entire frame, regardless of event ordering.
    // On a buttonpad, existing and newly starting contacts must pass through for
    // the click. Apply releases only after processing the frame's contacts.
    for event in physical_buttons.iter().filter(|event| event.value != 0) {
        promoted_contacts.extend(engine.update_physical_button(event.code, true));
    }

    let core_events = extract_core_events(frame);
    let output = match frame.timestamp {
        Some(timestamp) => engine.process_frame_at(&core_events, timestamp)?,
        None => engine.process_frame(&core_events)?,
    };
    for event in physical_buttons.iter().filter(|event| event.value == 0) {
        engine.update_physical_button(event.code, false);
    }
    promoted_contacts.extend(output.passthrough.iter().copied());
    let passthrough = raw_passthrough_events_for_core_passthrough(frame, &promoted_contacts);

    canceled_tap_gestures.extend(output.gestures);
    Ok(RoutedRawFrame {
        passthrough,
        physical_buttons,
        gestures: canceled_tap_gestures,
        slider_steps: output.slider_steps,
        resync_required: output.resync_required,
    })
}

pub fn route_recognition_deadline(engine: &mut Engine, timestamp: Duration) -> RoutedRawFrame {
    let output = engine.advance_time(timestamp);
    RoutedRawFrame {
        passthrough: Vec::new(),
        physical_buttons: Vec::new(),
        gestures: output.gestures,
        slider_steps: Vec::new(),
        resync_required: false,
    }
}

pub fn route_resync_contacts(
    engine: &mut Engine,
    contacts: &[ResyncContact],
) -> Result<RoutedRawFrame, SlotError> {
    let output = engine.restore_passthrough_contacts(contacts)?;
    Ok(RoutedRawFrame {
        passthrough: output
            .passthrough
            .into_iter()
            .filter_map(raw_event_for_core_event)
            .collect(),
        physical_buttons: Vec::new(),
        gestures: Vec::new(),
        slider_steps: Vec::new(),
        resync_required: false,
    })
}

fn raw_passthrough_events_for_core_passthrough(
    _frame: &RawFrame,
    core_passthrough: &[Event],
) -> Vec<RawEvent> {
    core_passthrough
        .iter()
        .copied()
        .filter_map(raw_event_for_core_event)
        .collect()
}

fn raw_event_for_core_event(event: Event) -> Option<RawEvent> {
    match event {
        Event::Slot(slot) => Some(RawEvent::abs_mt_slot(slot)),
        Event::TrackingId(tracking_id) => Some(RawEvent::abs_mt_tracking_id(tracking_id)),
        Event::X(x) => Some(RawEvent::abs_mt_position_x(x)),
        Event::Y(y) => Some(RawEvent::abs_mt_position_y(y)),
        Event::SynDropped => None,
    }
}

fn core_event_for_raw_event(event: RawEvent) -> Option<Event> {
    match (event.kind, event.code) {
        (EV_ABS, ABS_MT_SLOT) => Some(Event::slot(event.value)),
        (EV_ABS, ABS_MT_TRACKING_ID) => Some(Event::tracking_id(event.value)),
        (EV_ABS, ABS_MT_POSITION_X) => Some(Event::x(event.value)),
        (EV_ABS, ABS_MT_POSITION_Y) => Some(Event::y(event.value)),
        (EV_SYN, SYN_DROPPED) => Some(Event::syn_dropped()),
        _ => None,
    }
}
