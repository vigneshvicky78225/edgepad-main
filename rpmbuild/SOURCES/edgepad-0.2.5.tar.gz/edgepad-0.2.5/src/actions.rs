//! Run configured commands off the input thread.
//!
//! A single worker preserves command order. Its bounded queue drops new actions
//! when full, so a slow command cannot block touchpad forwarding or grow an
//! unlimited backlog of slider steps.

use std::collections::HashSet;
use std::io;
#[cfg(unix)]
use std::os::unix::process::CommandExt;
use std::process::{Child, Command};
use std::sync::{
    atomic::{AtomicBool, AtomicU64, Ordering},
    mpsc::{sync_channel, Receiver, SyncSender, TrySendError},
    Arc, Mutex,
};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant};

#[cfg(test)]
use crate::config::CommandActionConfig;
use crate::config::{
    GestureActionConfig, GestureBindingConfig, SliderActionConfig, SliderBindingConfig,
};
#[cfg(test)]
use crate::core::SliderAxis;
use crate::core::{
    Gesture, GestureCancellation, GestureDirection, SliderDirection, SliderStep, Zone,
};
use crate::ipc::IpcBroadcaster;
use crate::keyboard::VirtualKeyboard;
use crate::proxy::GestureHandler;

const ACTION_COMMAND_INITIAL_POLL_INTERVAL: Duration = Duration::from_millis(1);
const ACTION_COMMAND_MAX_POLL_INTERVAL: Duration = Duration::from_millis(10);
const ACTION_WORKER_SHUTDOWN_TIMEOUT: Duration = Duration::from_secs(1);
const ACTION_WORKER_SHUTDOWN_JOIN_POLL_INTERVAL: Duration = Duration::from_millis(10);

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ActionDispatcherStats {
    pub matched_gestures: usize,
    pub unmatched_gestures: usize,
    pub matched_slider_steps: usize,
    pub unmatched_slider_steps: usize,
    pub log_actions: usize,
    pub queued_commands: usize,
    pub dropped_commands: usize,
    pub started_commands: usize,
    pub succeeded_commands: usize,
    pub failed_commands: usize,
    pub worker_panics: usize,
    pub worker_shutdown_timeouts: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ActionCommandStatus {
    pub success: bool,
}

impl ActionCommandStatus {
    pub fn success() -> Self {
        Self { success: true }
    }

    pub fn failure() -> Self {
        Self { success: false }
    }
}

pub trait ActionCommandRunner: Send + 'static {
    fn run(
        &mut self,
        argv: &[String],
        shutdown: &ActionShutdownToken,
    ) -> Result<ActionCommandStatus, String>;
}

#[derive(Debug, Clone, Default)]
pub struct ActionShutdownToken {
    requested: Arc<AtomicBool>,
}

impl ActionShutdownToken {
    pub fn is_requested(&self) -> bool {
        self.requested.load(Ordering::SeqCst)
    }

    fn request(&self) {
        self.requested.store(true, Ordering::SeqCst);
    }
}

#[derive(Debug, Default)]
pub struct ProcessCommandRunner;

impl ActionCommandRunner for ProcessCommandRunner {
    fn run(
        &mut self,
        argv: &[String],
        shutdown: &ActionShutdownToken,
    ) -> Result<ActionCommandStatus, String> {
        let (program, args) = argv
            .split_first()
            .ok_or_else(|| "command action argv must not be empty".to_string())?;
        let mut child = spawn_action_command(program, args)?;
        let mut poll_interval = ACTION_COMMAND_INITIAL_POLL_INTERVAL;

        loop {
            if let Some(status) = child
                .try_wait()
                .map_err(|err| format!("failed to poll action command {program:?}: {err}"))?
            {
                return Ok(ActionCommandStatus {
                    success: status.success(),
                });
            }

            if shutdown.is_requested() {
                if let Some(status) = child.try_wait().map_err(|err| {
                    format!("failed to poll action command {program:?} before shutdown kill: {err}")
                })? {
                    return Ok(ActionCommandStatus {
                        success: status.success(),
                    });
                }

                match kill_action_child(&mut child, program) {
                    Ok(true) => {
                        child.wait().map_err(|err| {
                            format!("failed to wait for killed action command {program:?}: {err}")
                        })?;
                        return Err(format!(
                            "action command {program:?} interrupted by daemon shutdown"
                        ));
                    }
                    Ok(false) => {
                        let status = child.wait().map_err(|err| {
                            format!("failed to wait for action command {program:?}: {err}")
                        })?;
                        return Ok(ActionCommandStatus {
                            success: status.success(),
                        });
                    }
                    Err(err) => {
                        return Err(err);
                    }
                }
            }

            thread::sleep(poll_interval);
            poll_interval = next_action_command_poll_interval(poll_interval);
        }
    }
}

fn next_action_command_poll_interval(current: Duration) -> Duration {
    std::cmp::min(current.saturating_mul(2), ACTION_COMMAND_MAX_POLL_INTERVAL)
}

fn spawn_action_command(program: &str, args: &[String]) -> Result<Child, String> {
    let mut command = Command::new(program);
    command.args(args);
    // Isolate each action so shutdown can also stop children of `sh -c`,
    // without signaling the daemon's own process group.
    #[cfg(unix)]
    command.process_group(0);
    command
        .spawn()
        .map_err(|err| format!("failed to spawn action command {program:?}: {err}"))
}

fn kill_action_child(child: &mut Child, program: &str) -> Result<bool, String> {
    #[cfg(unix)]
    {
        let process_group = child.id() as libc::pid_t;
        let result = unsafe { libc::kill(-process_group, libc::SIGKILL) };
        if result == 0 {
            return Ok(true);
        }

        let err = io::Error::last_os_error();
        if err.raw_os_error() == Some(libc::ESRCH) {
            return Ok(false);
        }

        Err(format!(
            "failed to kill action command process group {program:?} during daemon shutdown: {err}"
        ))
    }

    #[cfg(not(unix))]
    {
        match child.kill() {
            Ok(()) => Ok(true),
            Err(err) if err.kind() == io::ErrorKind::InvalidInput => Ok(false),
            Err(err) => Err(format!(
                "failed to kill action command {program:?} during daemon shutdown: {err}"
            )),
        }
    }
}

#[derive(Debug)]
pub struct ActionDispatcher {
    bindings: Vec<GestureBindingConfig>,
    sliders: Vec<SliderBindingConfig>,
    sender: Option<SyncSender<ActionCommand>>,
    stats: SharedActionStats,
    worker: Option<JoinHandle<()>>,
    shutdown: ActionShutdownToken,
    test_mode: Arc<AtomicBool>,
    broadcaster: Option<IpcBroadcaster>,
    repeat_interval_ms: Arc<AtomicU64>,
    cancelled_contacts: Arc<Mutex<HashSet<(i32, i32)>>>,
}

impl ActionDispatcher {
    pub fn new(bindings: Vec<GestureBindingConfig>, queue_capacity: usize) -> Result<Self, String> {
        Self::with_runner(bindings, queue_capacity, ProcessCommandRunner)
    }

    pub fn new_with_sliders(
        bindings: Vec<GestureBindingConfig>,
        sliders: Vec<SliderBindingConfig>,
        queue_capacity: usize,
    ) -> Result<Self, String> {
        Self::with_runner_and_sliders(bindings, sliders, queue_capacity, ProcessCommandRunner)
    }

    pub fn with_runner<R>(
        bindings: Vec<GestureBindingConfig>,
        queue_capacity: usize,
        runner: R,
    ) -> Result<Self, String>
    where
        R: ActionCommandRunner,
    {
        Self::with_runner_and_sliders(bindings, Vec::new(), queue_capacity, runner)
    }

    pub fn with_runner_and_sliders<R>(
        bindings: Vec<GestureBindingConfig>,
        sliders: Vec<SliderBindingConfig>,
        queue_capacity: usize,
        runner: R,
    ) -> Result<Self, String>
    where
        R: ActionCommandRunner,
    {
        let (sender, receiver) = sync_channel(queue_capacity);
        let stats = SharedActionStats::default();
        let worker_stats = stats.clone();
        let shutdown = ActionShutdownToken::default();
        let worker_shutdown = shutdown.clone();
        let test_mode = Arc::new(AtomicBool::new(false));
        let worker_test_mode = test_mode.clone();
        let broadcaster = IpcBroadcaster::new();
        let worker_broadcaster = broadcaster.clone();
        let repeat_interval_ms = Arc::new(AtomicU64::new(
            crate::encoder::DEFAULT_ENCODER_REPEAT_INTERVAL_MS,
        ));
        let worker_repeat_interval_ms = repeat_interval_ms.clone();
        let cancelled_contacts = Arc::new(Mutex::new(HashSet::new()));
        let worker_cancelled_contacts = cancelled_contacts.clone();

        let worker_ctx = ActionWorkerContext {
            stats: worker_stats,
            shutdown: worker_shutdown,
            test_mode: worker_test_mode,
            broadcaster: worker_broadcaster,
            repeat_interval_ms: worker_repeat_interval_ms,
            cancelled_contacts: worker_cancelled_contacts,
        };

        let worker = thread::Builder::new()
            .name("edgepad-action-worker".to_string())
            .spawn(move || run_action_worker(receiver, runner, worker_ctx))
            .map_err(|err| format!("failed to start edgepad action worker: {err}"))?;

        Ok(Self {
            bindings,
            sliders,
            sender: Some(sender),
            stats,
            worker: Some(worker),
            shutdown,
            test_mode,
            broadcaster: Some(broadcaster),
            repeat_interval_ms,
            cancelled_contacts,
        })
    }

    pub fn set_repeat_interval_ms(&self, ms: u64) {
        let clamped = ms.clamp(
            crate::encoder::MIN_ENCODER_REPEAT_INTERVAL_MS,
            crate::encoder::MAX_ENCODER_REPEAT_INTERVAL_MS,
        );
        self.repeat_interval_ms.store(clamped, Ordering::SeqCst);
    }

    pub fn repeat_interval_ms(&self) -> u64 {
        self.repeat_interval_ms.load(Ordering::SeqCst)
    }

    pub fn set_test_mode(&self, enabled: bool) {
        self.test_mode.store(enabled, Ordering::SeqCst);
    }

    pub fn is_test_mode(&self) -> bool {
        self.test_mode.load(Ordering::SeqCst)
    }

    pub fn test_mode_flag(&self) -> Arc<AtomicBool> {
        self.test_mode.clone()
    }

    pub fn set_broadcaster(&mut self, broadcaster: IpcBroadcaster) {
        self.broadcaster = Some(broadcaster);
    }

    pub fn broadcaster(&self) -> Option<IpcBroadcaster> {
        self.broadcaster.clone()
    }

    pub fn dispatch_gesture(&mut self, gesture: Gesture) {
        let binding = self
            .bindings
            .iter()
            .find(|binding| binding.matches(&gesture))
            .or_else(|| {
                // If this is a directional swipe originating in a corner, fall back to adjacent edge
                if matches!(
                    gesture.direction,
                    GestureDirection::Up
                        | GestureDirection::Down
                        | GestureDirection::Left
                        | GestureDirection::Right
                ) {
                    let fallback_zone = match (gesture.zone, gesture.direction) {
                        (Zone::TopLeft, GestureDirection::Up | GestureDirection::Down) => {
                            Some(Zone::Left)
                        }
                        (Zone::TopLeft, GestureDirection::Left | GestureDirection::Right) => {
                            Some(Zone::Top)
                        }
                        (Zone::TopRight, GestureDirection::Up | GestureDirection::Down) => {
                            Some(Zone::Right)
                        }
                        (Zone::TopRight, GestureDirection::Left | GestureDirection::Right) => {
                            Some(Zone::Top)
                        }
                        (Zone::BottomLeft, GestureDirection::Up | GestureDirection::Down) => {
                            Some(Zone::Left)
                        }
                        (Zone::BottomLeft, GestureDirection::Left | GestureDirection::Right) => {
                            Some(Zone::Bottom)
                        }
                        (Zone::BottomRight, GestureDirection::Up | GestureDirection::Down) => {
                            Some(Zone::Right)
                        }
                        (Zone::BottomRight, GestureDirection::Left | GestureDirection::Right) => {
                            Some(Zone::Bottom)
                        }
                        _ => None,
                    };
                    fallback_zone.and_then(|fz| {
                        let fallback_gesture = Gesture {
                            zone: fz,
                            ..gesture
                        };
                        self.bindings.iter().find(|b| b.matches(&fallback_gesture))
                    })
                } else {
                    None
                }
            });

        let Some(binding) = binding else {
            self.stats.increment_unmatched_gestures();
            eprintln!("edgepad action unmatched: {}", gesture_context(gesture));
            eprintln!(
                "[EDGEPAD_EVENT] [7/7-FAILURE] No matching configuration rule found for zone {:?} gesture {:?}",
                gesture.zone, gesture.direction
            );
            if let Some(ref bcast) = self.broadcaster {
                let json = format!(
                    r#"{{"event":"unmatched_gesture","zone":"{}","direction":"{}","slot":{},"tracking_id":{}}}"#,
                    zone_name(gesture.zone),
                    direction_name(gesture.direction),
                    gesture.slot,
                    gesture.tracking_id
                );
                bcast.broadcast(&json);
            }
            return;
        };

        self.stats.increment_matched_gestures();
        eprintln!(
            "[EDGEPAD_EVENT] [4/7-RULE_MATCHED] Rule matched for zone {:?} gesture {:?}: action={:?}",
            gesture.zone, gesture.direction, binding.action
        );
        match &binding.action {
            GestureActionConfig::Log => {
                self.stats.increment_log_actions();
                eprintln!(
                    "edgepad action log: zone={} direction={} slot={} tracking_id={}",
                    zone_name(gesture.zone),
                    direction_name(gesture.direction),
                    gesture.slot,
                    gesture.tracking_id
                );
                if let Some(ref bcast) = self.broadcaster {
                    let json = format!(
                        r#"{{"event":"gesture","zone":"{}","direction":"{}","action_type":"log","action":"log","success":true}}"#,
                        zone_name(gesture.zone),
                        direction_name(gesture.direction)
                    );
                    bcast.broadcast(&json);
                }
            }
            GestureActionConfig::Command { argv } => {
                self.enqueue_action_command(
                    ActionSource::Gesture(gesture),
                    ActionPayload::Command(argv.clone()),
                );
            }
            GestureActionConfig::Key {
                key_code,
                key_name,
                repeat,
            } => {
                self.enqueue_action_command(
                    ActionSource::Gesture(gesture),
                    ActionPayload::Key {
                        key_code: *key_code,
                        key_name: key_name.clone(),
                        repeat: *repeat,
                    },
                );
            }
            GestureActionConfig::KeyCombo {
                key_codes,
                key_names,
            } => {
                self.enqueue_action_command(
                    ActionSource::Gesture(gesture),
                    ActionPayload::KeyCombo {
                        key_codes: key_codes.clone(),
                        key_names: key_names.clone(),
                    },
                );
            }
        }
    }

    pub fn dispatch_slider_step(&mut self, step: SliderStep) {
        // 1. Check if there is an explicit slider binding configured for this zone & direction
        if let Some(slider) = self.sliders.iter().find(|slider| {
            slider.enabled && slider.zone == step.zone && slider.direction_is_valid(step.direction)
        }) {
            self.stats.increment_matched_slider_steps();
            match slider.action_for(step.direction) {
                SliderActionConfig::Command(cmd) => {
                    self.enqueue_action_command(
                        ActionSource::SliderStep(step),
                        ActionPayload::Command(cmd.argv.clone()),
                    );
                }
                SliderActionConfig::Key {
                    key_code,
                    key_name,
                    repeat,
                } => {
                    self.enqueue_action_command(
                        ActionSource::SliderStep(step),
                        ActionPayload::Key {
                            key_code: *key_code,
                            key_name: key_name.clone(),
                            repeat: *repeat,
                        },
                    );
                }
            }
            return;
        }

        // 2. Check if there is a gesture binding configured for this zone & direction
        let gesture_dir = match step.direction {
            SliderDirection::Up => GestureDirection::Up,
            SliderDirection::Down => GestureDirection::Down,
            SliderDirection::Left => GestureDirection::Left,
            SliderDirection::Right => GestureDirection::Right,
        };
        if let Some(binding) = self
            .bindings
            .iter()
            .find(|b| b.enabled && b.zone == step.zone && b.direction == gesture_dir)
        {
            self.stats.increment_matched_slider_steps();
            match &binding.action {
                GestureActionConfig::Key {
                    key_code, key_name, ..
                } => {
                    self.enqueue_action_command(
                        ActionSource::SliderStep(step),
                        ActionPayload::Key {
                            key_code: *key_code,
                            key_name: key_name.clone(),
                            repeat: 1,
                        },
                    );
                }
                GestureActionConfig::KeyCombo {
                    key_codes,
                    key_names,
                } => {
                    self.enqueue_action_command(
                        ActionSource::SliderStep(step),
                        ActionPayload::KeyCombo {
                            key_codes: key_codes.clone(),
                            key_names: key_names.clone(),
                        },
                    );
                }
                GestureActionConfig::Command { argv } => {
                    self.enqueue_action_command(
                        ActionSource::SliderStep(step),
                        ActionPayload::Command(argv.clone()),
                    );
                }
                GestureActionConfig::Log => {
                    self.stats.increment_log_actions();
                    eprintln!(
                        "edgepad slider action log: zone={} direction={} slot={} tracking_id={}",
                        zone_name(step.zone),
                        slider_direction_name(step.direction),
                        step.slot,
                        step.tracking_id
                    );
                    if let Some(ref bcast) = self.broadcaster {
                        let json = format!(
                            r#"{{"event":"slider_step","zone":"{}","direction":"{}","action_type":"log","action":"log","success":true}}"#,
                            zone_name(step.zone),
                            slider_direction_name(step.direction)
                        );
                        bcast.broadcast(&json);
                    }
                }
            }
            return;
        }

        // 3. Fallback to standard hardware defaults:
        // Left edge: Up -> KEY_BRIGHTNESSUP (225), Down -> KEY_BRIGHTNESSDOWN (224)
        // Right edge: Up -> KEY_VOLUMEUP (115), Down -> KEY_VOLUMEDOWN (114)
        // Top edge: Right -> KEY_NEXTSONG (163), Left -> KEY_PREVIOUSSONG (165)
        // Bottom edge: Right -> KEY_RIGHT (106), Left -> KEY_LEFT (105)
        let default_key = match (step.zone, step.direction) {
            (Zone::Left, SliderDirection::Up) => Some((225, "KEY_BRIGHTNESSUP")),
            (Zone::Left, SliderDirection::Down) => Some((224, "KEY_BRIGHTNESSDOWN")),
            (Zone::Right, SliderDirection::Up) => Some((115, "KEY_VOLUMEUP")),
            (Zone::Right, SliderDirection::Down) => Some((114, "KEY_VOLUMEDOWN")),
            (Zone::Top, SliderDirection::Right) => Some((163, "KEY_NEXTSONG")),
            (Zone::Top, SliderDirection::Left) => Some((165, "KEY_PREVIOUSSONG")),
            (Zone::Top, SliderDirection::Up) => Some((163, "KEY_NEXTSONG")),
            (Zone::Top, SliderDirection::Down) => Some((165, "KEY_PREVIOUSSONG")),
            (Zone::Bottom, SliderDirection::Right) => Some((106, "KEY_RIGHT")),
            (Zone::Bottom, SliderDirection::Left) => Some((105, "KEY_LEFT")),
            (Zone::Bottom, SliderDirection::Up) => Some((103, "KEY_UP")),
            (Zone::Bottom, SliderDirection::Down) => Some((108, "KEY_DOWN")),
            _ => None,
        };

        if let Some((code, name)) = default_key {
            self.stats.increment_matched_slider_steps();
            self.enqueue_action_command(
                ActionSource::SliderStep(step),
                ActionPayload::Key {
                    key_code: code,
                    key_name: name.to_string(),
                    repeat: 1,
                },
            );
        } else {
            self.stats.increment_unmatched_slider_steps();
            eprintln!("edgepad slider unmatched: {}", slider_step_context(step));
        }
    }

    pub fn stats(&self) -> ActionDispatcherStats {
        self.stats.snapshot()
    }

    /// Replace bindings for future dispatches. Already queued commands keep
    /// their original argv, so a reload does not reinterpret an earlier gesture.
    pub fn reconfigure(
        &mut self,
        bindings: Vec<GestureBindingConfig>,
        sliders: Vec<SliderBindingConfig>,
    ) {
        self.bindings = bindings;
        self.sliders = sliders;
    }

    pub fn shutdown(mut self) -> ActionDispatcherStats {
        self.shutdown.request();
        self.sender.take();
        if let Some(worker) = self.worker.take() {
            if wait_for_action_worker_shutdown(&worker, ACTION_WORKER_SHUTDOWN_TIMEOUT) {
                if worker.join().is_err() {
                    self.stats.increment_worker_panics();
                }
            } else {
                self.stats.increment_worker_shutdown_timeouts();
                eprintln!(
                    "edgepad action worker did not stop within {:.1}s; daemon shutdown will continue",
                    ACTION_WORKER_SHUTDOWN_TIMEOUT.as_secs_f32()
                );
            }
        }
        self.stats.snapshot()
    }

    fn enqueue_action_command(&self, source: ActionSource, payload: ActionPayload) {
        let Some(sender) = &self.sender else {
            self.stats.increment_dropped_commands();
            return;
        };

        match sender.try_send(ActionCommand { source, payload }) {
            Ok(()) => self.stats.increment_queued_commands(),
            Err(TrySendError::Full(_)) | Err(TrySendError::Disconnected(_)) => {
                self.stats.increment_dropped_commands();
            }
        }
    }
    pub fn cancel_gesture(&mut self, cancel: GestureCancellation) {
        self.cancelled_contacts
            .lock()
            .unwrap()
            .insert((cancel.slot, cancel.tracking_id));
        self.enqueue_action_command(
            ActionSource::Cancellation(cancel),
            ActionPayload::CancelContact {
                slot: cancel.slot,
                tracking_id: cancel.tracking_id,
            },
        );
    }
}

impl GestureHandler for ActionDispatcher {
    fn handle_gesture(&mut self, gesture: Gesture) {
        self.dispatch_gesture(gesture);
    }

    fn handle_slider_step(&mut self, step: SliderStep) {
        self.dispatch_slider_step(step);
    }

    fn handle_cancellation(&mut self, cancel: GestureCancellation) {
        self.cancel_gesture(cancel);
    }
}

#[derive(Debug, Clone)]
pub enum ActionPayload {
    Command(Vec<String>),
    Key {
        key_code: u16,
        key_name: String,
        repeat: u32,
    },
    KeyCombo {
        key_codes: Vec<u16>,
        key_names: Vec<String>,
    },
    CancelContact {
        slot: i32,
        tracking_id: i32,
    },
}

#[derive(Debug, Clone)]
struct ActionCommand {
    source: ActionSource,
    payload: ActionPayload,
}

#[derive(Debug, Clone, Copy)]
enum ActionSource {
    Gesture(Gesture),
    SliderStep(SliderStep),
    Cancellation(GestureCancellation),
}

impl ActionSource {
    pub fn slot(&self) -> i32 {
        match self {
            ActionSource::Gesture(g) => g.slot,
            ActionSource::SliderStep(s) => s.slot,
            ActionSource::Cancellation(c) => c.slot,
        }
    }

    pub fn tracking_id(&self) -> i32 {
        match self {
            ActionSource::Gesture(g) => g.tracking_id,
            ActionSource::SliderStep(s) => s.tracking_id,
            ActionSource::Cancellation(c) => c.tracking_id,
        }
    }
}

struct ActionWorkerContext {
    stats: SharedActionStats,
    shutdown: ActionShutdownToken,
    test_mode: Arc<AtomicBool>,
    broadcaster: IpcBroadcaster,
    repeat_interval_ms: Arc<AtomicU64>,
    cancelled_contacts: Arc<Mutex<HashSet<(i32, i32)>>>,
}

fn run_action_worker<R>(
    receiver: Receiver<ActionCommand>,
    mut runner: R,
    worker_ctx: ActionWorkerContext,
) where
    R: ActionCommandRunner,
{
    let ActionWorkerContext {
        stats,
        shutdown,
        test_mode,
        broadcaster,
        repeat_interval_ms,
        cancelled_contacts,
    } = worker_ctx;

    let mut keyboard: Option<VirtualKeyboard> = None;

    while !shutdown.is_requested() {
        let Ok(command) = receiver.recv() else {
            break;
        };
        if shutdown.is_requested() {
            break;
        }

        let source_slot = command.source.slot();
        let source_tracking_id = command.source.tracking_id();

        if let ActionPayload::CancelContact { .. } = &command.payload {
            if let Some(ref mut kb) = keyboard {
                let _ = kb.release_all();
            }
            continue;
        }

        if cancelled_contacts
            .lock()
            .unwrap()
            .contains(&(source_slot, source_tracking_id))
        {
            stats.increment_dropped_commands();
            eprintln!(
                "[EDGEPAD_EVENT] [ACTION_CANCELLED] Dropping queued action for cancelled contact (slot={}, tracking_id={})",
                source_slot, source_tracking_id
            );
            continue;
        }

        let is_test = test_mode.load(Ordering::SeqCst);
        let ctx = action_command_context(&command);
        let (source_type, zone, direction) = match command.source {
            ActionSource::Gesture(g) => ("gesture", zone_name(g.zone), direction_name(g.direction)),
            ActionSource::SliderStep(s) => (
                "slider_step",
                zone_name(s.zone),
                slider_direction_name(s.direction),
            ),
            ActionSource::Cancellation(c) => ("cancellation", zone_name(c.zone), "none"),
        };

        match &command.payload {
            ActionPayload::Command(argv) => {
                stats.increment_started_commands();
                eprintln!(
                    "[EDGEPAD_EVENT] [5/7-ACTION_DISPATCHED] Dispatching command {:?} for {} (test_mode={})",
                    argv, ctx, is_test
                );
                if is_test {
                    stats.increment_succeeded_commands();
                    eprintln!(
                        "edgepad [TEST MODE] simulated command: {} argv={:?}",
                        ctx, argv
                    );
                    eprintln!(
                        "[EDGEPAD_EVENT] [6/7-ACTION_EXECUTED] Simulated command {:?} succeeded (test_mode=true)",
                        argv
                    );
                    let json = format!(
                        r#"{{"event":"{}","zone":"{}","direction":"{}","action_type":"command","action":{:?},"test_mode":true,"success":true}}"#,
                        source_type, zone, direction, argv
                    );
                    broadcaster.broadcast(&json);
                } else {
                    let result = runner.run(argv, &shutdown);
                    let success = match result {
                        Ok(status) if status.success => {
                            stats.increment_succeeded_commands();
                            eprintln!(
                                "[EDGEPAD_EVENT] [6/7-ACTION_EXECUTED] Command {:?} completed successfully",
                                argv
                            );
                            true
                        }
                        Ok(_) => {
                            stats.increment_failed_commands();
                            eprintln!(
                                "edgepad action command exited unsuccessfully: {} argv={:?}",
                                ctx, argv
                            );
                            eprintln!(
                                "[EDGEPAD_EVENT] [7/7-FAILURE] Command {:?} exited with unsuccessful status",
                                argv
                            );
                            false
                        }
                        Err(err) => {
                            stats.increment_failed_commands();
                            eprintln!(
                                "edgepad action command failed: {} argv={:?}: {err}",
                                ctx, argv
                            );
                            eprintln!(
                                "[EDGEPAD_EVENT] [7/7-FAILURE] Command {:?} execution error: {err}",
                                argv
                            );
                            false
                        }
                    };
                    let json = format!(
                        r#"{{"event":"{}","zone":"{}","direction":"{}","action_type":"command","action":{:?},"test_mode":false,"success":{}}}"#,
                        source_type, zone, direction, argv, success
                    );
                    broadcaster.broadcast(&json);
                }
            }
            ActionPayload::Key {
                key_code,
                key_name,
                repeat,
            } => {
                stats.increment_started_commands();
                eprintln!(
                    "[EDGEPAD_EVENT] [5/7-ACTION_DISPATCHED] Dispatching key {} ({}) repeat={} for {} (test_mode={})",
                    key_name, key_code, repeat, ctx, is_test
                );
                if is_test {
                    stats.increment_succeeded_commands();
                    eprintln!(
                        "edgepad [TEST MODE] simulated key: {} key={} (code {})",
                        ctx, key_name, key_code
                    );
                    eprintln!(
                        "[EDGEPAD_EVENT] [6/7-ACTION_EXECUTED] Simulated key {} (code {}) succeeded (test_mode=true)",
                        key_name, key_code
                    );
                    let json = format!(
                        r#"{{"event":"{}","zone":"{}","direction":"{}","action_type":"key","key":"{}","key_code":{},"test_mode":true,"success":true}}"#,
                        source_type, zone, direction, key_name, key_code
                    );
                    broadcaster.broadcast(&json);
                } else {
                    if keyboard.is_none() {
                        match VirtualKeyboard::new() {
                            Ok(kb) => keyboard = Some(kb),
                            Err(err) => {
                                eprintln!("edgepad failed to initialize virtual keyboard: {err}");
                                eprintln!(
                                    "[EDGEPAD_EVENT] [7/7-FAILURE] Failed to initialize virtual keyboard: {err}"
                                );
                            }
                        }
                    }

                    let interval = repeat_interval_ms.load(Ordering::SeqCst);
                    let hold_ms = (interval / 2).max(4);
                    let pause_ms = interval.saturating_sub(hold_ms).max(4);
                    let hold_dur = Duration::from_millis(hold_ms);
                    let pause_dur = Duration::from_millis(pause_ms);

                    let success = if let Some(ref mut kb) = keyboard {
                        let mut ok = true;
                        for i in 0..*repeat {
                            if let Err(err) = kb.tap(*key_code, hold_dur) {
                                eprintln!(
                                    "edgepad failed to emit key {} ({}): {err}",
                                    key_name, key_code
                                );
                                eprintln!(
                                    "[EDGEPAD_EVENT] [7/7-FAILURE] Failed to emit key {} (code {}): {err}",
                                    key_name, key_code
                                );
                                ok = false;
                                break;
                            }
                            if i + 1 < *repeat || !pause_dur.is_zero() {
                                thread::sleep(pause_dur);
                            }
                        }
                        if ok {
                            stats.increment_succeeded_commands();
                            eprintln!(
                                "[EDGEPAD_EVENT] [6/7-ACTION_EXECUTED] Virtual key {} (code {}) emitted successfully",
                                key_name, key_code
                            );
                        } else {
                            stats.increment_failed_commands();
                        }
                        ok
                    } else {
                        stats.increment_failed_commands();
                        eprintln!(
                            "[EDGEPAD_EVENT] [7/7-FAILURE] Cannot emit key {}: virtual keyboard unavailable",
                            key_name
                        );
                        false
                    };

                    let json = format!(
                        r#"{{"event":"{}","zone":"{}","direction":"{}","action_type":"key","key":"{}","key_code":{},"test_mode":false,"success":{}}}"#,
                        source_type, zone, direction, key_name, key_code, success
                    );
                    broadcaster.broadcast(&json);
                }
            }
            ActionPayload::KeyCombo {
                key_codes,
                key_names,
            } => {
                stats.increment_started_commands();
                let combo_str = key_names.join(" + ");
                eprintln!(
                    "[EDGEPAD_EVENT] [5/7-ACTION_DISPATCHED] Dispatching shortcut {} ({:?}) for {} (test_mode={})",
                    combo_str, key_codes, ctx, is_test
                );
                if is_test {
                    stats.increment_succeeded_commands();
                    eprintln!(
                        "edgepad [TEST MODE] simulated shortcut: {} combo={} (codes {:?})",
                        ctx, combo_str, key_codes
                    );
                    eprintln!(
                        "[EDGEPAD_EVENT] [6/7-ACTION_EXECUTED] Simulated shortcut {} succeeded (test_mode=true)",
                        combo_str
                    );
                    let json = format!(
                        r#"{{"event":"{}","zone":"{}","direction":"{}","action_type":"shortcut","shortcut":"{}","keys":{:?},"test_mode":true,"success":true}}"#,
                        source_type, zone, direction, combo_str, key_names
                    );
                    broadcaster.broadcast(&json);
                } else {
                    if keyboard.is_none() {
                        match VirtualKeyboard::new() {
                            Ok(kb) => keyboard = Some(kb),
                            Err(err) => {
                                eprintln!("edgepad failed to initialize virtual keyboard: {err}");
                                eprintln!(
                                    "[EDGEPAD_EVENT] [7/7-FAILURE] Failed to initialize virtual keyboard: {err}"
                                );
                            }
                        }
                    }

                    let hold_dur = Duration::from_millis(20);
                    let success = if let Some(ref mut kb) = keyboard {
                        if let Err(err) = kb.emit_combo(key_codes, hold_dur) {
                            eprintln!("edgepad failed to emit shortcut {}: {err}", combo_str);
                            eprintln!(
                                "[EDGEPAD_EVENT] [7/7-FAILURE] Failed to emit shortcut {}: {err}",
                                combo_str
                            );
                            stats.increment_failed_commands();
                            false
                        } else {
                            stats.increment_succeeded_commands();
                            eprintln!(
                                "[EDGEPAD_EVENT] [6/7-ACTION_EXECUTED] Virtual shortcut {} emitted successfully",
                                combo_str
                            );
                            true
                        }
                    } else {
                        stats.increment_failed_commands();
                        eprintln!(
                            "[EDGEPAD_EVENT] [7/7-FAILURE] Cannot emit shortcut {}: virtual keyboard unavailable",
                            combo_str
                        );
                        false
                    };

                    let json = format!(
                        r#"{{"event":"{}","zone":"{}","direction":"{}","action_type":"shortcut","shortcut":"{}","keys":{:?},"test_mode":false,"success":{}}}"#,
                        source_type, zone, direction, combo_str, key_names, success
                    );
                    broadcaster.broadcast(&json);
                }
            }
            ActionPayload::CancelContact { .. } => {}
        }
    }

    if let Some(mut kb) = keyboard {
        let _ = kb.release_all();
    }
}

fn action_command_context(command: &ActionCommand) -> String {
    action_source_context(command.source)
}

fn action_source_context(source: ActionSource) -> String {
    match source {
        ActionSource::Gesture(gesture) => gesture_context(gesture),
        ActionSource::SliderStep(step) => slider_step_context(step),
        ActionSource::Cancellation(cancel) => cancellation_context(cancel),
    }
}

fn cancellation_context(cancel: GestureCancellation) -> String {
    format!(
        "zone={} cancellation slot={} tracking_id={}",
        zone_name(cancel.zone),
        cancel.slot,
        cancel.tracking_id
    )
}

fn gesture_context(gesture: Gesture) -> String {
    format!(
        "zone={} direction={} slot={} tracking_id={}",
        zone_name(gesture.zone),
        direction_name(gesture.direction),
        gesture.slot,
        gesture.tracking_id
    )
}

fn slider_step_context(step: SliderStep) -> String {
    format!(
        "zone={} direction={} slot={} tracking_id={}",
        zone_name(step.zone),
        slider_direction_name(step.direction),
        step.slot,
        step.tracking_id
    )
}

fn wait_for_action_worker_shutdown(worker: &JoinHandle<()>, timeout: Duration) -> bool {
    let started_at = Instant::now();
    while !worker.is_finished() {
        if started_at.elapsed() >= timeout {
            return false;
        }

        let remaining = timeout.saturating_sub(started_at.elapsed());
        thread::sleep(ACTION_WORKER_SHUTDOWN_JOIN_POLL_INTERVAL.min(remaining));
    }
    true
}

#[derive(Debug, Clone, Default)]
struct SharedActionStats {
    stats: Arc<Mutex<ActionDispatcherStats>>,
}

impl SharedActionStats {
    fn snapshot(&self) -> ActionDispatcherStats {
        self.stats
            .lock()
            .expect("action stats mutex should not be poisoned")
            .clone()
    }

    fn update(&self, update: impl FnOnce(&mut ActionDispatcherStats)) {
        let mut stats = self
            .stats
            .lock()
            .expect("action stats mutex should not be poisoned");
        update(&mut stats);
    }

    fn increment_matched_gestures(&self) {
        self.update(|stats| stats.matched_gestures += 1);
    }

    fn increment_unmatched_gestures(&self) {
        self.update(|stats| stats.unmatched_gestures += 1);
    }

    fn increment_matched_slider_steps(&self) {
        self.update(|stats| stats.matched_slider_steps += 1);
    }

    fn increment_unmatched_slider_steps(&self) {
        self.update(|stats| stats.unmatched_slider_steps += 1);
    }

    fn increment_log_actions(&self) {
        self.update(|stats| stats.log_actions += 1);
    }

    fn increment_queued_commands(&self) {
        self.update(|stats| stats.queued_commands += 1);
    }

    fn increment_dropped_commands(&self) {
        self.update(|stats| stats.dropped_commands += 1);
    }

    fn increment_started_commands(&self) {
        self.update(|stats| stats.started_commands += 1);
    }

    fn increment_succeeded_commands(&self) {
        self.update(|stats| stats.succeeded_commands += 1);
    }

    fn increment_failed_commands(&self) {
        self.update(|stats| stats.failed_commands += 1);
    }

    fn increment_worker_panics(&self) {
        self.update(|stats| stats.worker_panics += 1);
    }

    fn increment_worker_shutdown_timeouts(&self) {
        self.update(|stats| stats.worker_shutdown_timeouts += 1);
    }
}

fn zone_name(zone: Zone) -> &'static str {
    match zone {
        Zone::Left => "left",
        Zone::Right => "right",
        Zone::Top => "top",
        Zone::Bottom => "bottom",
        Zone::TopLeft => "top-left",
        Zone::TopRight => "top-right",
        Zone::BottomLeft => "bottom-left",
        Zone::BottomRight => "bottom-right",
    }
}

fn direction_name(direction: GestureDirection) -> &'static str {
    match direction {
        GestureDirection::Up => "up",
        GestureDirection::Down => "down",
        GestureDirection::Left => "left",
        GestureDirection::Right => "right",
        GestureDirection::Tap => "tap",
        GestureDirection::DoubleTap => "double-tap",
    }
}

fn slider_direction_name(direction: SliderDirection) -> &'static str {
    match direction {
        SliderDirection::Up => "up",
        SliderDirection::Down => "down",
        SliderDirection::Left => "left",
        SliderDirection::Right => "right",
    }
}

#[cfg(test)]
mod tests {
    use std::sync::mpsc;
    use std::time::{Duration, Instant};

    use super::*;

    #[derive(Debug)]
    struct RecordingRunner {
        sender: mpsc::Sender<Vec<String>>,
        status: ActionCommandStatus,
    }

    impl ActionCommandRunner for RecordingRunner {
        fn run(
            &mut self,
            argv: &[String],
            _shutdown: &ActionShutdownToken,
        ) -> Result<ActionCommandStatus, String> {
            self.sender
                .send(argv.to_vec())
                .expect("recording runner receiver should be alive");
            Ok(self.status)
        }
    }

    #[test]
    fn matching_command_action_is_queued_and_waited_by_worker_runner() {
        let (sender, receiver) = mpsc::channel();
        let mut dispatcher = ActionDispatcher::with_runner(
            vec![binding(
                Zone::Left,
                GestureDirection::Right,
                GestureActionConfig::Command {
                    argv: vec![
                        "notify-send".to_string(),
                        "edgepad".to_string(),
                        "left right".to_string(),
                    ],
                },
            )],
            4,
            RecordingRunner {
                sender,
                status: ActionCommandStatus::success(),
            },
        )
        .expect("dispatcher should start");

        dispatcher.dispatch_gesture(gesture(Zone::Left, GestureDirection::Right));
        let argv = receiver
            .recv_timeout(Duration::from_secs(1))
            .expect("worker should run queued action");
        let stats = dispatcher.shutdown();

        assert_eq!(
            argv,
            vec![
                "notify-send".to_string(),
                "edgepad".to_string(),
                "left right".to_string()
            ]
        );
        assert_eq!(stats.matched_gestures, 1);
        assert_eq!(stats.queued_commands, 1);
        assert_eq!(stats.started_commands, 1);
        assert_eq!(stats.succeeded_commands, 1);
        assert_eq!(stats.failed_commands, 0);
    }

    #[test]
    fn matching_slider_step_action_is_queued_and_waited_by_worker_runner() {
        let (sender, receiver) = mpsc::channel();
        let mut dispatcher = ActionDispatcher::with_runner_and_sliders(
            Vec::new(),
            vec![slider_binding(
                Zone::Left,
                SliderDirection::Up,
                vec!["pamixer", "-d", "3"],
                SliderDirection::Down,
                vec!["pamixer", "-i", "3"],
            )],
            4,
            RecordingRunner {
                sender,
                status: ActionCommandStatus::success(),
            },
        )
        .expect("dispatcher should start");

        dispatcher.dispatch_slider_step(slider_step(Zone::Left, SliderDirection::Down));
        let argv = receiver
            .recv_timeout(Duration::from_secs(1))
            .expect("worker should run queued action");
        let stats = dispatcher.shutdown();

        assert_eq!(
            argv,
            vec!["pamixer".to_string(), "-i".to_string(), "3".to_string()]
        );
        assert_eq!(stats.matched_slider_steps, 1);
        assert_eq!(stats.queued_commands, 1);
        assert_eq!(stats.started_commands, 1);
        assert_eq!(stats.succeeded_commands, 1);
        assert_eq!(stats.failed_commands, 0);
    }

    #[test]
    fn unmatched_gesture_does_not_queue_action() {
        let (sender, receiver) = mpsc::channel();
        let mut dispatcher = ActionDispatcher::with_runner(
            vec![binding(
                Zone::Left,
                GestureDirection::Right,
                GestureActionConfig::Command {
                    argv: vec!["notify-send".to_string(), "edgepad".to_string()],
                },
            )],
            4,
            RecordingRunner {
                sender,
                status: ActionCommandStatus::success(),
            },
        )
        .expect("dispatcher should start");

        dispatcher.dispatch_gesture(gesture(Zone::Right, GestureDirection::Down));
        let stats = dispatcher.shutdown();

        assert!(receiver.try_recv().is_err());
        assert_eq!(stats.unmatched_gestures, 1);
        assert_eq!(stats.queued_commands, 0);
        assert_eq!(stats.started_commands, 0);
    }

    #[test]
    fn double_tap_binding_dispatches_only_the_sequence_gesture() {
        let (sender, receiver) = mpsc::channel();
        let mut dispatcher = ActionDispatcher::with_runner(
            vec![binding(
                Zone::Top,
                GestureDirection::DoubleTap,
                GestureActionConfig::Command {
                    argv: vec!["playerctl".to_string(), "stop".to_string()],
                },
            )],
            4,
            RecordingRunner {
                sender,
                status: ActionCommandStatus::success(),
            },
        )
        .expect("dispatcher should start");

        dispatcher.dispatch_gesture(gesture(Zone::Top, GestureDirection::DoubleTap));
        let argv = receiver
            .recv_timeout(Duration::from_secs(1))
            .expect("double-tap action should run");
        let stats = dispatcher.shutdown();

        assert_eq!(stats.matched_gestures, 1);
        assert_eq!(argv, vec!["playerctl".to_string(), "stop".to_string()]);
    }

    #[test]
    fn log_action_is_counted_without_queueing_command() {
        let (sender, receiver) = mpsc::channel();
        let mut dispatcher = ActionDispatcher::with_runner(
            vec![binding(
                Zone::Top,
                GestureDirection::Down,
                GestureActionConfig::Log,
            )],
            4,
            RecordingRunner {
                sender,
                status: ActionCommandStatus::success(),
            },
        )
        .expect("dispatcher should start");

        dispatcher.dispatch_gesture(gesture(Zone::Top, GestureDirection::Down));
        let stats = dispatcher.shutdown();

        assert!(receiver.try_recv().is_err());
        assert_eq!(stats.matched_gestures, 1);
        assert_eq!(stats.log_actions, 1);
        assert_eq!(stats.queued_commands, 0);
    }

    #[test]
    fn reconfigure_replaces_gesture_and_slider_lookups_without_restarting_worker() {
        let (sender, receiver) = mpsc::channel();
        let mut dispatcher = ActionDispatcher::with_runner(
            vec![binding(
                Zone::Left,
                GestureDirection::Right,
                GestureActionConfig::Log,
            )],
            4,
            RecordingRunner {
                sender,
                status: ActionCommandStatus::success(),
            },
        )
        .expect("dispatcher should start");

        dispatcher.dispatch_gesture(gesture(Zone::Right, GestureDirection::Down));
        dispatcher.reconfigure(
            vec![binding(
                Zone::Right,
                GestureDirection::Down,
                GestureActionConfig::Log,
            )],
            Vec::new(),
        );
        dispatcher.dispatch_gesture(gesture(Zone::Right, GestureDirection::Down));
        let stats = dispatcher.shutdown();

        assert!(receiver.try_recv().is_err());
        assert_eq!(stats.unmatched_gestures, 1);
        assert_eq!(stats.matched_gestures, 1);
        assert_eq!(stats.log_actions, 1);
    }

    #[test]
    fn failed_command_status_is_recorded() {
        let (sender, receiver) = mpsc::channel();
        let mut dispatcher = ActionDispatcher::with_runner(
            vec![binding(
                Zone::Bottom,
                GestureDirection::Up,
                GestureActionConfig::Command {
                    argv: vec!["false".to_string()],
                },
            )],
            4,
            RecordingRunner {
                sender,
                status: ActionCommandStatus::failure(),
            },
        )
        .expect("dispatcher should start");

        dispatcher.dispatch_gesture(gesture(Zone::Bottom, GestureDirection::Up));
        receiver
            .recv_timeout(Duration::from_secs(1))
            .expect("worker should run queued action");
        let stats = dispatcher.shutdown();

        assert_eq!(stats.started_commands, 1);
        assert_eq!(stats.succeeded_commands, 0);
        assert_eq!(stats.failed_commands, 1);
    }

    #[test]
    fn shutdown_interrupts_running_process_action() {
        let mut dispatcher = ActionDispatcher::with_runner(
            vec![binding(
                Zone::Right,
                GestureDirection::Down,
                GestureActionConfig::Command {
                    argv: vec!["sleep".to_string(), "10".to_string()],
                },
            )],
            4,
            ProcessCommandRunner,
        )
        .expect("dispatcher should start");

        dispatcher.dispatch_gesture(gesture(Zone::Right, GestureDirection::Down));
        wait_for_started_command(&dispatcher);

        let started_at = Instant::now();
        let stats = dispatcher.shutdown();

        assert!(
            started_at.elapsed() < Duration::from_secs(2),
            "shutdown should not wait for the full action command duration"
        );
        assert_eq!(stats.started_commands, 1);
        assert_eq!(stats.succeeded_commands, 0);
        assert_eq!(stats.failed_commands, 1);
        assert_eq!(stats.worker_shutdown_timeouts, 0);
    }

    #[test]
    fn action_command_poll_interval_backs_off_to_small_bound() {
        let first = ACTION_COMMAND_INITIAL_POLL_INTERVAL;
        let second = next_action_command_poll_interval(first);
        let third = next_action_command_poll_interval(second);

        assert!(first < Duration::from_millis(50));
        assert_eq!(second, Duration::from_millis(2));
        assert_eq!(third, Duration::from_millis(4));
        assert_eq!(
            next_action_command_poll_interval(Duration::from_millis(100)),
            ACTION_COMMAND_MAX_POLL_INTERVAL
        );
    }

    #[test]
    fn action_command_context_includes_gesture_identity() {
        let command = ActionCommand {
            source: ActionSource::Gesture(gesture(Zone::Right, GestureDirection::Up)),
            payload: ActionPayload::Command(vec!["notify-send".to_string(), "edgepad".to_string()]),
        };

        assert_eq!(
            action_command_context(&command),
            "zone=right direction=up slot=0 tracking_id=42"
        );
    }

    #[test]
    fn gesture_context_includes_gesture_identity() {
        assert_eq!(
            gesture_context(gesture(Zone::Top, GestureDirection::Left)),
            "zone=top direction=left slot=0 tracking_id=42"
        );
    }

    #[test]
    fn slider_step_context_includes_slider_identity() {
        assert_eq!(
            slider_step_context(slider_step(Zone::Right, SliderDirection::Up)),
            "zone=right direction=up slot=0 tracking_id=42"
        );
    }

    #[test]
    fn slider_step_selects_correct_hardware_default_keys() {
        let mut dispatcher = ActionDispatcher::with_runner(Vec::new(), 16, ProcessCommandRunner)
            .expect("dispatcher should start");
        dispatcher.set_test_mode(true);

        // Test fallback hardware defaults when no explicit bindings are configured:
        // Left Up -> KEY_BRIGHTNESSUP (225)
        dispatcher.dispatch_slider_step(slider_step(Zone::Left, SliderDirection::Up));
        // Left Down -> KEY_BRIGHTNESSDOWN (224)
        dispatcher.dispatch_slider_step(slider_step(Zone::Left, SliderDirection::Down));
        // Right Up -> KEY_VOLUMEUP (115)
        dispatcher.dispatch_slider_step(slider_step(Zone::Right, SliderDirection::Up));
        // Right Down -> KEY_VOLUMEDOWN (114)
        dispatcher.dispatch_slider_step(slider_step(Zone::Right, SliderDirection::Down));
        // Top Right -> KEY_NEXTSONG (163)
        dispatcher.dispatch_slider_step(slider_step(Zone::Top, SliderDirection::Right));
        // Top Left -> KEY_PREVIOUSSONG (165)
        dispatcher.dispatch_slider_step(slider_step(Zone::Top, SliderDirection::Left));
        // Bottom Right -> KEY_RIGHT (106)
        dispatcher.dispatch_slider_step(slider_step(Zone::Bottom, SliderDirection::Right));
        // Bottom Left -> KEY_LEFT (105)
        dispatcher.dispatch_slider_step(slider_step(Zone::Bottom, SliderDirection::Left));

        // Sleep briefly to let the test worker process the 8 commands
        thread::sleep(Duration::from_millis(60));
        let stats = dispatcher.shutdown();

        assert_eq!(stats.matched_slider_steps, 8);
        assert_eq!(stats.started_commands, 8);
        assert_eq!(stats.succeeded_commands, 8);
    }

    #[test]
    fn slider_step_honors_gesture_binding_if_configured() {
        let mut dispatcher = ActionDispatcher::with_runner(
            vec![binding(
                Zone::Left,
                GestureDirection::Up,
                GestureActionConfig::Key {
                    key_code: 104,
                    key_name: "KEY_PAGEUP".to_string(),
                    repeat: 1,
                },
            )],
            16,
            ProcessCommandRunner,
        )
        .expect("dispatcher should start");
        dispatcher.set_test_mode(true);

        dispatcher.dispatch_slider_step(slider_step(Zone::Left, SliderDirection::Up));
        thread::sleep(Duration::from_millis(30));
        let stats = dispatcher.shutdown();

        assert_eq!(stats.matched_slider_steps, 1);
        assert_eq!(stats.started_commands, 1);
        assert_eq!(stats.succeeded_commands, 1);
    }

    #[test]
    fn rapid_slider_ticks_do_not_block_and_complete_independently() {
        let mut dispatcher = ActionDispatcher::with_runner(Vec::new(), 32, ProcessCommandRunner)
            .expect("dispatcher should start");
        dispatcher.set_test_mode(true);
        dispatcher.set_repeat_interval_ms(10);

        // Rapid burst of 10 ticks (e.g. fast continuous swipe)
        for _ in 0..10 {
            dispatcher.dispatch_slider_step(slider_step(Zone::Right, SliderDirection::Up));
        }

        thread::sleep(Duration::from_millis(80));
        let stats = dispatcher.shutdown();

        assert_eq!(stats.matched_slider_steps, 10);
        assert_eq!(stats.started_commands, 10);
        assert_eq!(stats.succeeded_commands, 10);
        assert_eq!(stats.failed_commands, 0);
    }

    fn wait_for_started_command(dispatcher: &ActionDispatcher) {
        let started_at = Instant::now();
        while dispatcher.stats().started_commands == 0 {
            assert!(
                started_at.elapsed() < Duration::from_secs(1),
                "worker should start queued action command"
            );
            thread::sleep(Duration::from_millis(10));
        }
    }

    fn binding(
        zone: Zone,
        direction: GestureDirection,
        action: GestureActionConfig,
    ) -> GestureBindingConfig {
        GestureBindingConfig {
            zone,
            direction,
            action,
            name: None,
            enabled: true,
        }
    }

    fn gesture(zone: Zone, direction: GestureDirection) -> Gesture {
        Gesture {
            zone,
            direction,
            slot: 0,
            tracking_id: 42,
        }
    }

    fn slider_binding(
        zone: Zone,
        negative_direction: SliderDirection,
        negative: Vec<&str>,
        positive_direction: SliderDirection,
        positive: Vec<&str>,
    ) -> SliderBindingConfig {
        let axis = match (negative_direction, positive_direction) {
            (SliderDirection::Up, SliderDirection::Down) => SliderAxis::Vertical,
            (SliderDirection::Left, SliderDirection::Right) => SliderAxis::Horizontal,
            _ => panic!("invalid slider directions"),
        };
        SliderBindingConfig {
            zone,
            axis,
            step: 0.04,
            negative: SliderActionConfig::Command(command_action(negative)),
            positive: SliderActionConfig::Command(command_action(positive)),
            name: None,
            enabled: true,
        }
    }

    fn command_action(argv: Vec<&str>) -> CommandActionConfig {
        CommandActionConfig::new(argv).expect("test command should be valid")
    }

    fn slider_step(zone: Zone, direction: SliderDirection) -> SliderStep {
        SliderStep {
            zone,
            direction,
            slot: 0,
            tracking_id: 42,
        }
    }
}
